package edu.purdue.rcac.climatedata;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;


public class AboutFrame extends JFrame {
	private JPanel contentPane;

	public AboutFrame() {
		setTitle("About This Tool");
		String helpmessage = "";
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/doc/readme.html")));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			br.close();
			helpmessage = sb.toString();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 450, 560);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JEditorPane dtrpnAbout = new JEditorPane();
		dtrpnAbout.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				URL url = e.getURL();
				HyperlinkEvent.EventType type = e.getEventType();
				
				try {
					if(type == HyperlinkEvent.EventType.ACTIVATED) {
						Utils.viewExternally(url);
					}
					
				} catch (MalformedURLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalStateException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		dtrpnAbout.setBounds(26, 15, 400, 450);
		dtrpnAbout.setContentType("text/html");
		dtrpnAbout.setText(helpmessage);
		dtrpnAbout.setBackground(UIManager.getColor("Panel.background"));
		dtrpnAbout.setEditable(false);
		panel.add(dtrpnAbout);
		
	}
}

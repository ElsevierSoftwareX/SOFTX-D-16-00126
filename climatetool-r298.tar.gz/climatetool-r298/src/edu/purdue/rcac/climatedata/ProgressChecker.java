package edu.purdue.rcac.climatedata;

import javax.swing.JProgressBar;

public class ProgressChecker extends Thread {
	
	private JProgressBar progressBar;
	public ProgressChecker(JProgressBar bar) {
		progressBar = bar;
	}
	public void run() {
		progressBar.setStringPainted(true);
		while(MainFrame.getCounter() != progressBar.getMaximum()) {
			progressBar.setValue(MainFrame.getCounter());
			progressBar.setString(MainFrame.getCounter() + "%");
		}
		progressBar.setValue(MainFrame.getCounter());
		progressBar.setString(MainFrame.getCounter() + "%");
	}
}

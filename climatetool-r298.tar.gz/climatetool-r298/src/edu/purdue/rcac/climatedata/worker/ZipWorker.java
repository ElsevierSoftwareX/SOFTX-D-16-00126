package edu.purdue.rcac.climatedata.worker;

import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import edu.purdue.rcac.climatedata.MainFrame;
import edu.purdue.rcac.climatedata.Utils;

public class ZipWorker extends SwingWorker<String, Void>
{

	private MainFrame gui;
	
	private static Logger logger = Logger.getLogger(MainFrame.class.getName());
	
	private String cmd;
	private String zipFilePath;
	
	public ZipWorker(MainFrame gui, String cmd, String zipFilePath) 
	{
		this.gui = gui;
		this.cmd = cmd;
		this.zipFilePath = zipFilePath;
	}
	
	@Override
	protected String doInBackground() throws Exception
	{
		String output = runCommand(cmd, zipFilePath);
		return output;
	}

	@Override
	public void done() {
		try 
		{
			String output = get();
//			gui.getScriptoutputTextArea().append(output);
			logger.info(output);
			MainFrame.setDownloadProgress(false);
			gui.getMainProgressBar().setIndeterminate(false);
			gui.getOutputTextArea().append("Done!\n");
			
			if(output.equals("DONE"))
			{
				File f = new File(zipFilePath);
				if(f.exists())
				{
					logger.info("Download data : " + f.toString());
					Utils.downloadFile(f.toString());
				}
				else
				{
					JOptionPane.showMessageDialog(null,
							"No File Exists", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
			
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		} catch (ExecutionException ex) {
			ex.printStackTrace();
		}
//		gui.getCommandProgressbar().setIndeterminate(false);
//		gui.getBtnSubmit().setEnabled(true);
//		gui.getBtnReset().setEnabled(true);
	}
	
	private String runCommand(String command, String zipfilePath) throws InterruptedException
	{
		try
		{
			
			File zip = new File(zipfilePath);
			String workingDirectoryPath = zip.getParent();
			File workingDirectory = new File(workingDirectoryPath);
			
			logger.info("zip command : " + command);
			Process p = Runtime.getRuntime().exec(command, null, workingDirectory);
			p.waitFor();
			
		} 
		catch (IOException e1)
		{
			e1.printStackTrace();
		}
		
		return "DONE";
		
//		gui.getOutputTextArea().append("Done!\n");
		
		// Download
		
	}
	
	
	
	
}

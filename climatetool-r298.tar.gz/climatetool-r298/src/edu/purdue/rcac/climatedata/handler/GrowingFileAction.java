package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.UIManager;

import edu.purdue.rcac.climatedata.MainFrame;

public class GrowingFileAction  extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private MainFrame gui;
	
	public GrowingFileAction(MainFrame gui) 
	{
		putValue(NAME, "Browse Growing FIle");
		putValue(SHORT_DESCRIPTION, "select grwing season files");
		
		this.gui = gui;
	}

	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
		UIManager.put("FileChooser.readOnly", Boolean.TRUE);  
		  
		JFileChooser fileChooser = new JFileChooser(gui.getGrowingSeasonDir());
//		fileChooser.setMultiSelectionEnabled(true);
		
		UIManager.put("FileChooser.readOnly", old);  
		  
		int retval = fileChooser.showOpenDialog(gui);
		
		if (retval == JFileChooser.APPROVE_OPTION)
		{
			String fname = fileChooser.getSelectedFile().getAbsolutePath();

			gui.getTextGrwoingFile().setText(fname);
			gui.setGrowingSeasonFile(new File(gui.getTextGrwoingFile().getText()) );

//			gui.getRdbtnMax().setEnabled(false);
//			gui.getRdbtnMin().setEnabled(false);
//			gui.getRdbtnMean().setEnabled(false);
//			gui.getRdbtnSd().setEnabled(false);

		}
		
	}

}
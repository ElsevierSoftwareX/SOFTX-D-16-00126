package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import edu.purdue.rcac.climatedata.MainFrame;

public class ClimateFileAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private MainFrame gui;
	private static Logger logger = Logger.getLogger(MainFrame.class.getName());

	
	public ClimateFileAction(MainFrame gui) 
	{
		putValue(NAME, "Browse");
		putValue(SHORT_DESCRIPTION, "select climate files");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
		Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
		UIManager.put("FileChooser.readOnly", Boolean.TRUE);  
//		logger.info("path : " + gui.getDownloadPath());
		
		
		JFileChooser fileChooser = null;
		File f = new File(gui.getDownloadPath());
		if(f.exists())
			fileChooser = new JFileChooser(gui.getDownloadPath());
		else
			fileChooser = new JFileChooser(gui.getDefaultDownloadPath() + "inputs");
		
		
		fileChooser.setMultiSelectionEnabled(true);
		
		UIManager.put("FileChooser.readOnly", old);
		
		int retval = fileChooser.showOpenDialog(gui);
		
		if (retval == JFileChooser.APPROVE_OPTION) 
		{

			gui.setClimateFileList(fileChooser.getSelectedFiles());

			StringBuffer filelists = new StringBuffer();
			for (File file : fileChooser.getSelectedFiles()) {
				filelists.append(file.getPath()
						+ System.getProperty("line.separator"));
			}
			gui.getTxtClimate().setText(filelists.toString());
			
//			logger.info("?????????????????????????????????????????");
//			logger.info(gui.getTxtClimate().getText());
//			logger.info("?????????????????????????????????????????");
		
			ArrayList<Integer> ar = new ArrayList<Integer>();
			int minStartYear = 9999;
			int maxEndYear = 0;
			
			for (int i = 0; i < gui.getClimateFileList().length; i++) 
			{
//				logger.info(gui.getClimateFileList()[i].toString());
				
				String climateFileName = gui.getClimateFileList()[i].getName();
				String subfilename = climateFileName.substring(0,
						climateFileName.lastIndexOf(".mm.nc"));
				
				StringTokenizer st = new StringTokenizer(subfilename,"_");
				
				String climate = st.nextToken();
				String bced =  st.nextToken();
				String observeFromYear =  st.nextToken();
				String observeToYear =  st.nextToken();
				String gcm = st.nextToken();
				String rcp =  st.nextToken();
				String years = st.nextToken();
				
				int start_year = 0;
				int end_year = 0;
				
				StringTokenizer yt = new StringTokenizer(years,"-");
				if(yt.countTokens() == 2)
				{
					start_year = Integer.parseInt(yt.nextToken());
					end_year = Integer.parseInt(yt.nextToken());
//					gui.setSyear(start_year);
//					gui.setEyear(end_year);
				}
				else
				{
					start_year = Integer.parseInt(yt.nextToken());
					end_year = start_year;
//					gui.setSyear(start_year);
//					gui.setEyear(start_year);
				}
				
				
				for(int y = start_year ; y <= end_year ; y++)
				{
					ar.add(y);
				}
				
				if(start_year <= minStartYear)
					minStartYear = start_year;
				
				if(end_year >= maxEndYear)
					maxEndYear = end_year;
				
			}
			
//			logger.info("minStartYear : " + minStartYear);
//			logger.info("maxEndYear : " + maxEndYear);
			
			int numYears = maxEndYear - minStartYear + 1;
			
			
//			logger.info("numYears : " + numYears);
			
			Collections.sort(ar);
			
//			for(int item : ar)
//				logger.info(Integer.toString(item));
			
			boolean cons = true;
			for(int y = 0, t = minStartYear; y < ar.size(); y++, t++)
			{
				if( ar.get(y) != t )
					cons = false;
			}
			
			if(!cons)
			{
				JOptionPane.showMessageDialog(gui,
					"Data files need to have continuous years", "Warning",
					JOptionPane.WARNING_MESSAGE);
				
				gui.setClimateFileList(null);
				gui.getTxtClimate().setText(gui.getClimateFileName());
				
				return;
			}
			
			gui.setMinStartYear(minStartYear);
			gui.setMaxEndYear(maxEndYear);
			
			
		}
	}
}
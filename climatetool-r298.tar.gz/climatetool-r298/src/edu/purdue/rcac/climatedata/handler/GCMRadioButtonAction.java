package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JRadioButton;

import edu.purdue.rcac.climatedata.MainFrame;

public class GCMRadioButtonAction extends AbstractAction 
{
	private MainFrame gui;
	
	public GCMRadioButtonAction(JRadioButton radiobutton, MainFrame gui) 
	{
		putValue(NAME, radiobutton.getText());
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
		gui.setGcm(gui.getSelectedButtonText(gui.getGCMButtonGroup()));
		gui.setRcp(gui.getSelectedButtonText(gui.getRCPButtonGroup()));
		gui.setClimate(gui.getSelectedButtonText(gui.getClimateButtonGroup()));
		
		String path = gui.getGcm() + "/" + gui.getRcp() + "/" + gui.getClimate();
		
		gui.getTxtPathfields().setText(gui.getPrefix() + "/" + path);
	}
}

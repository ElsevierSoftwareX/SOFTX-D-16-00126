package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.swing.AbstractAction;

import edu.purdue.rcac.climatedata.MainFrame;
import edu.purdue.rcac.climatedata.Utils;

public class RegionFileUploadAction extends AbstractAction 
{
	private MainFrame gui;
	
	public RegionFileUploadAction(MainFrame gui)
	{
		putValue(NAME, "Upload");
		putValue(SHORT_DESCRIPTION, "upload region.map file");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
	
		Executor executor = Executors.newFixedThreadPool(2);
		Runnable runnable = new Runnable() {
			public void run() {
				// import the file
				String path = Utils.importFile(gui.getUserHome(),
						"for Region File", -1);
				
				gui.getTxtRegionFile().setText(path);
				gui.setRegionFile( new File(gui.getTxtRegionFile().getText()) );
			}
		};
		executor.execute(runnable);
	}
}
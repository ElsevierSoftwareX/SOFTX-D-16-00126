package edu.purdue.rcac.climatedata.handler;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import edu.purdue.rcac.climatedata.MainFrame;

public class CheckBoxEnableGrowingAction extends AbstractAction 
{
	private MainFrame gui;
	
	public CheckBoxEnableGrowingAction(MainFrame gui)
	{
		putValue(NAME, "Obtain annual growing season averages");
		putValue(SHORT_DESCRIPTION, "check to enable growing aggregate");
		
		this.gui = gui;
		
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (gui.getChckbxEnableGrowingSeasons().isSelected() == true)
		{
			gui.getTextGrwoingFile().setEnabled(true);
			gui.getTextGrwoingFile().setForeground(Color.BLACK);
			
			gui.getBtnGrowingButton().setEnabled(true);
			
			gui.setGrowingSeasonFile(new File(gui.getTextGrwoingFile().getText()));
		}
		else
		{
			gui.getTextGrwoingFile().setEnabled(false);
			gui.getTextGrwoingFile().setForeground(Color.LIGHT_GRAY);
			
			gui.getBtnGrowingButton().setEnabled(false);
			
			gui.setGrowingSeasonFile(null);
		}
		
	}
}
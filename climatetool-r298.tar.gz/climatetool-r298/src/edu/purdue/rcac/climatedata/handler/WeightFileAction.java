package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import edu.purdue.rcac.climatedata.MainFrame;

public class WeightFileAction extends AbstractAction 
{
	private MainFrame gui;
	
	public WeightFileAction(MainFrame gui) 
	{
		putValue(NAME, "Browse");
		putValue(SHORT_DESCRIPTION, "select weight.map file");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
		JFileChooser fileChooser = new JFileChooser(gui.getWeightMapDir());
		FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV",
				"csv");
		fileChooser.setFileFilter(filter);
		int retval = fileChooser.showOpenDialog(gui);
		if (retval == JFileChooser.APPROVE_OPTION) {
			String fname = fileChooser.getSelectedFile().getAbsolutePath();

			gui.getTxtWeightFile().setText(fname);
			gui.setWeightFile( new File(gui.getTxtWeightFile().getText()) );

			gui.getRdbtnMax().setEnabled(false);
			gui.getRdbtnMin().setEnabled(false);
			gui.getRdbtnMean().setEnabled(false);
			gui.getRdbtnSd().setEnabled(false);

		}
	}
}
package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.swing.AbstractAction;

import edu.purdue.rcac.climatedata.MainFrame;
import edu.purdue.rcac.climatedata.Utils;

public class WeightFileUploadAction extends AbstractAction
{
	private MainFrame gui;
	
	public WeightFileUploadAction(MainFrame gui) 
	{
		putValue(NAME, "Upload");
		putValue(SHORT_DESCRIPTION, "Upload weight.map file");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
	
		Executor executor = Executors.newFixedThreadPool(2);
		Runnable runnable = new Runnable() 
		{
			public void run() 
			{
				// import the file
				String path = Utils.importFile(gui.getUserHome(),
						"for Region File", -1);
				
				gui.getTxtWeightFile().setText(path);
				gui.setWeightFile( new File(gui.getTxtWeightFile().getText()) );

				gui.getRdbtnMax().setEnabled(false);
				gui.getRdbtnMin().setEnabled(false);
				gui.getRdbtnMean().setEnabled(false);
				gui.getRdbtnSd().setEnabled(false);
			}
		};
		executor.execute(runnable);
	}
}
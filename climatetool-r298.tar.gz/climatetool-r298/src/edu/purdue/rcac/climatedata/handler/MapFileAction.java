package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.logging.Logger;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

import edu.purdue.rcac.climatedata.MainFrame;

public class MapFileAction extends AbstractAction 
{
	private MainFrame gui;
	private static Logger logger = Logger.getLogger(MainFrame.class.getName());
	
	public MapFileAction(MainFrame gui) 
	{
		putValue(NAME, "Browse");
		putValue(SHORT_DESCRIPTION, "select source file to generate maps");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
		Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
		UIManager.put("FileChooser.readOnly", Boolean.TRUE);  
		  
		JFileChooser fileChooser = new JFileChooser(gui.getOutputPath());
		FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV",
				"csv");
		fileChooser.setFileFilter(filter);
	
		UIManager.put("FileChooser.readOnly", old);  
		  
		  
		int retval = fileChooser.showOpenDialog(gui);
		if (retval == JFileChooser.APPROVE_OPTION) {
			String fname = fileChooser.getSelectedFile().getAbsolutePath();
			File file = new File(fname);
			// regionfile = fileChooser.getSelectedFile();
			gui.getTextMapField().setText(file.getName());
			gui.setMapSourceFile(fname);
			logger.info("mapsourcefile:" + gui.getMapSourceFile());

		}
	}
}
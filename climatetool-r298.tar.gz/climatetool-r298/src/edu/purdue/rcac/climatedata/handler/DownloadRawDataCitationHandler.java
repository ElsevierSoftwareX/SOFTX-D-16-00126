package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import edu.purdue.rcac.climatedata.MainFrame;
import edu.purdue.rcac.climatedata.Utils;
import edu.purdue.rcac.climatedata.MainFrame.Pair;



public class DownloadRawDataCitationHandler  implements ActionListener
{
	private static Logger logger = Logger.getLogger(MainFrame.class.getName());
	private MainFrame gui;

	public DownloadRawDataCitationHandler(MainFrame gui)
	{
		this.gui = gui;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		
		String path = "";
		if (gui.getGcm().equals("") || gui.getRcp().equals("") || gui.getClimate().equals("")) {
			JOptionPane
					.showMessageDialog(
							null,
							"Please check all the options for crop data to see suggested citation",
							"Warning", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		
		
		/**
		 * make suggested citation
		 */
		
		// calculate periods
		StringBuffer citationString = new StringBuffer();
		String citationFileName = "";
		
		try {

			
			logger.info("making citaion: climateFileName " + gui.getClimateFileName());
			logger.info("climate " + gui.getClimate());
			String c = gui.getClimate();
			String climateName;
			if (c.equals("tas")) {
				climateName = "Average Surface Air Temperature";
			} else if (c.equals("tasmax")) {
				climateName = "Maximum Surface Air Temperature";
			} else if (c.equals("tasmin")) {
				climateName = "Minimum Surface Air Temperature";
			} else if (c.equals("pr")) {
				climateName = "Precipitation";
			} else {
				climateName = "Others";
			}
			logger.info("climateName " + climateName);
			
			
//			citationString.append("NetCDF (" + climateName + ") file with grid-cell level");
			
			
			
			String rcp = gui.getFullNameOfParameter(gui.getRcp());
//			citationString.append("----" + rcp + "-----");
			
			
			
			String gcmName = gui.getFullNameOfParameter(gui.getGcm());
//			citationString.append("????" + gcmName + "????");
			
//			citationString.append(" generated"
//					+ " using climate data from the " + gcmName
//					+ " GCM under representative concentration pathway "
//					+ gui.getRcp() + " ");
			
			
			citationString.append("Grid-cell level " + climateName + " from " + gcmName + " " 
									+ "under representative concentration pathway " + rcp + " "
									+ "downloaded from the ISI-MIP ESGF Node (details in Elliott et al., 2014).");
			
			citationString.append("\r\n\r\n\r\n");
			citationString.append("References");
			citationString.append("\r\n\r\n\r\n");
			
			citationString.append("Elliott, J., C. Mueller, D. Deryng, J. Chryssanthacopoulos, K. J. Boote, M. Buechner, I. Foster, et al. "
					+ "\"The Global Gridded Crop Model Intercomparison: Data and Modeling Protocols for Phase 1 (v1.0).\" "
					+ "Geosci. Model Dev. Discuss. 7, no. 4 (July 15, 2014): 4383-4427.");
			
//			citationString
//					.append("as documented in Rosenzweig et al. (2014), Elliott et al. (2014), Nelson et al. (2014), and Mueller and Robertson (2014).\n\n");

			
			citationFileName = gui.getTempPath() + "Data_Description_" + gui.getGcm() + "_"  + gui.getRcp() + "_" + gui.getClimate() + ".txt";
			


//			BufferedReader br = new BufferedReader(new InputStreamReader(
//					getClass().getResourceAsStream("/doc/references_raw.txt"),
//					"UTF-8"));
//			StringBuilder sb = new StringBuilder();
//			String line = br.readLine();
//
//			while (line != null) {
//				sb.append(line);
//				sb.append("\n");
//				line = br.readLine();
//			}
//			br.close();
//			citationString.append(sb.toString());

		} catch (Exception e1) {
			logger.info(e1.toString());
			e1.printStackTrace();
		}
		
		
		logger.info("citation file: " + citationFileName);
		logger.info(citationString.toString());

		try
		{
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(citationFileName), "UTF-8"));
			
			out.write(citationString.toString());
			out.flush();
			out.close();

		} 
		catch (UnsupportedEncodingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// Download the file
		File f = new File(citationFileName);
		if(f.exists())
		{
			logger.info("Download citation data : " + f.toString());
			Utils.downloadFile(f.toString());
		}
		else
		{
			JOptionPane.showMessageDialog(null,
					"No File Exists", "Warning",
					JOptionPane.WARNING_MESSAGE);
			return;
		}
		
//
//		File file = new File(citationFileName);
//		String outmsg;
//		if (file.isFile() && file.exists()) {
//			outputfilelist.add(citationFileName);
//			logger.info(citationFileName + " added");
//		} else {
//			outmsg = "Process completed abnomally: No citation file";
//			logger.info(outmsg);
//			return outmsg;
//		}
//
//		outputfilelist.add(citationFileName);
		/**
		 * end making citations
		 */
		
	}

}

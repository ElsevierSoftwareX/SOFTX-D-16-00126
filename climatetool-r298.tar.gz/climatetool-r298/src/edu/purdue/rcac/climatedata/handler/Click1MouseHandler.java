package edu.purdue.rcac.climatedata.handler;

import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import edu.purdue.rcac.climatedata.MainFrame;

public class Click1MouseHandler implements MouseListener
{
	private MainFrame gui;
	private JLabel label;
//	private Font bold;
//	private Font normal;
	
	public Click1MouseHandler(MainFrame gui, JLabel label)
	{
		this.gui = gui;
		this.label = label;
		
//		this.bold = new Font("Calibri", Font.ITALIC, 12);
//		this.normal = new Font("Calibri", Font.PLAIN, 12);
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0)
	{
		JOptionPane.showMessageDialog(
				gui,
				"For more details of sources as well as data processing consult Villoria et al. (2015), "
				+ "\navailable for download in the main page of this tool",
				"Warning", JOptionPane.WARNING_MESSAGE);
	}
	@Override
	public void mouseEntered(MouseEvent arg0)
	{
		label.setText("<HTML><U>( ! )</U></HTML>");
		
	}
	@Override
	public void mouseExited(MouseEvent arg0)
	{
		label.setText("<HTML>( ! )</HTML>");
	}
	@Override
	public void mousePressed(MouseEvent arg0){	}
	@Override
	public void mouseReleased(MouseEvent arg0){	}
}

package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.AbstractAction;

import edu.purdue.rcac.climatedata.AboutFrame;
import edu.purdue.rcac.climatedata.Utils;

public class AboutAction extends AbstractAction {
	public AboutAction() 
	{
		putValue(NAME, "Help");////
		putValue(SHORT_DESCRIPTION, "About this tool");
	}

	public void actionPerformed(ActionEvent e) {
		String urlstr = "https://geoshareproject.org/tools/cropdatatool/wiki";

		final URL url;
		try {
			url = new URL(urlstr);

			class OpenUrlAction implements ActionListener {
				@Override
				public void actionPerformed(ActionEvent e) {
					try {
						Utils.viewExternally(url);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			AboutFrame frame = new AboutFrame();
			frame.setSize(450, 250);
			frame.setVisible(true);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
package edu.purdue.rcac.climatedata.handler;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;

import edu.purdue.rcac.climatedata.MainFrame;

public class CheckBoxAction extends AbstractAction 
{
	private MainFrame gui;
	
	public CheckBoxAction(MainFrame gui)
	{
		putValue(NAME, "Enable Functions");
		putValue(SHORT_DESCRIPTION, "check to enable functions");
		
		this.gui = gui;
		
	}

	public void actionPerformed(ActionEvent e) {
		if (gui.getChckbxFunctionEnable().isSelected() == true) 
		{
			gui.getRdbtnMax().setEnabled(true);
			gui.getRdbtnMin().setEnabled(true);
			gui.getRdbtnMean().setEnabled(true);
			gui.getRdbtnSd().setEnabled(true);
		
			gui.getTxtWeightFile().setEnabled(false);
			gui.getTxtWeightFile().setForeground(Color.LIGHT_GRAY);
			
			gui.setWeightFile(null);

		} else 
		{
			gui.getRdbtnMax().setEnabled(false);
			gui.getRdbtnMin().setEnabled(false);
			gui.getRdbtnMean().setEnabled(false);
			gui.getRdbtnSd().setEnabled(false);
			gui.getTxtWeightFile().setEnabled(true);
			gui.getTxtWeightFile().setForeground(Color.BLACK);
			
			gui.setWeightFile( new File(gui.getTxtWeightFile().getText()) );
			gui.getAggregationButtonGroup().clearSelection();
			gui.setFunctioName(null);
		}
	}
}
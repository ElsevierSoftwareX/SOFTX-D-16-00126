package edu.purdue.rcac.climatedata.handler;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

import edu.purdue.rcac.climatedata.MainFrame;

public class RegionFileAction extends AbstractAction 
{
	private MainFrame gui;
	
	public RegionFileAction(MainFrame gui)
	{
		putValue(NAME, "Browse");
		putValue(SHORT_DESCRIPTION, "select region.map file");
		
		this.gui = gui;
	}

	public void actionPerformed(ActionEvent e) 
	{
		Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
		UIManager.put("FileChooser.readOnly", Boolean.TRUE);  
		  
		JFileChooser fileChooser = new JFileChooser(gui.getRegionMapDir());
		FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV",
				"csv");
		fileChooser.setFileFilter(filter);
	  
		UIManager.put("FileChooser.readOnly", old);  
		 
		int retval = fileChooser.showOpenDialog(gui);
		if (retval == JFileChooser.APPROVE_OPTION) {
			String fname = fileChooser.getSelectedFile().getAbsolutePath();
			// regionfile = fileChooser.getSelectedFile();
			gui.getTxtRegionFile().setText(fname);
			gui.setRegionFile(new File(gui.getTxtRegionFile().getText()));

		}
	}
}
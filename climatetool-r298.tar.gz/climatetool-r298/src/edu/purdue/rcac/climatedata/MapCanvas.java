package edu.purdue.rcac.climatedata;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;


public class MapCanvas extends Canvas {

	URL fileURL;
	Image map;

	MapCanvas(URL url) {
		fileURL = url;
		map = Utils.scaleImage(630, 420, fileURL);
	}

	public void paint(Graphics g) {
		update(g);
	}

	public void update(Graphics g) {

		g.drawImage(map, 0, 0, this);
	}
	
	public void setMap(URL url) {
		fileURL = url;
		map = Utils.scaleImage(630, 420, fileURL);
	}
	public void setMap(File file) {
		try {
			fileURL = file.toURI().toURL();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map = Utils.scaleImage(630, 420, fileURL);
	}
}
